# 验收日志审阅包（2026-08-23）

## 这是什么

两个演示场景的完整验收日志存档，供对照需求指标逐项审核：

| 目录 | 场景 | 验证内容 |
| --- | --- | --- |
| `rir_jammed_scan/` | 远程识别雷达受干扰探测（component_attachment demo，400 周期） | 雷达类需求指标全集；重点：外部干扰单音到达时「干扰信号处理增益」四行子项出真值 |
| `sbirs_dual_sat_fix/` | 双星交会定位（precision_evaluation demo，60 周期） | 红外类需求指标全集 + 精度评估（交会/AHP） |

`scenes/` 内附两个场景的配置文件与场景预期表（含链路依据与实测数据）。

## 产生条件

- 代码版本：1q 仓库 `feature/observability-single-source` 分支，commit `22c73067`（2026-08-23）
- 验收日志为库编译期开关（默认关闭），产生本包时打开的开关：
  - rir_jammed_scan：`ONEQ_ENABLE_RIR/FUSION/INFERENCE_ACCEPTANCE_LOG=ON`
  - sbirs_dual_sat_fix：`ONEQ_ENABLE_PRECISION_EVALUATION/SBIRS/FUSION/INFERENCE_ACCEPTANCE_LOG=ON`
- 复现方式：以对应开关重新配置并构建 `component_attachment_demo` / `precision_evaluation_demo`，分别以两场景 JSON 运行即可。

## 文件清单

**rir_jammed_scan/**：`rir_acceptance.log`（雷达类全部行，8 MB 主体）、`fusion/inference_acceptance.log`、`integration_events/views.log`（过程事件）、`rir_antenna_pattern.csv` / `rir_scan_pattern.csv`（波位/扫描序列表）、`platform_track/target_truth/route_plan/zones.csv`（真值与平台轨迹）。

**sbirs_dual_sat_fix/**：`sbirs_acceptance.log`（红外类全部行）、`precision_acceptance.log`（交会误差与 AHP）、`fusion/inference_acceptance.log`。

## 指标覆盖结论（本包日志实测）

### rir_jammed_scan ↔ 雷达类需求指标：28/28 有行

- 雷达·探测 8/8：天线方向图、回波功率、干扰功率、接收机噪声、目标信号增益（4 行）、噪声增益（4 行）、杂波信号处理（4 行）、**干扰信号处理增益（7 行；干扰周期 600/800 行真值——MTI 干扰剩余 1.091e-02W、8 通道非均分分布、抑制比 −1.537dB；ECM 停发周期如实写「无」）**
- 雷达·跟踪识别 12/12：指定空域搜索（含角域裁剪）、角度/距离测量、典型/再入跟踪、多目标跟踪、航迹关联、跟踪滤波、RCS 实时探测、运动特征、RCS 统计、极化特征（含 L2 五行）、宽带一维像、集群目标识别
- 雷达·调度 2/2：波束扫描、调度策略
- 性能测试（rir 侧）6/6：四个计时项占位「暂无」（真值在 integration_events.log 的 example 层记录）、连续运行次数、典型场景与总仿真次数

### sbirs_dual_sat_fix ↔ 红外类需求指标：16/17 有行

- 红外·探测 5/5：最大探测距离、可探测性与动态参数、卫星自身定位误差、红外载荷测角误差、安装矩阵误差
- 红外·宽窄视场 5/5：大幅面扫描、宽窄联合探测、宽视场扫描、窄视场跟踪、协同工作机制
- 性能测试（sbirs 侧）7/7：红外系统测角误差、组件模型参数性能、连续运行次数、典型场景、初始化/单步占位、**卫星 ECEF 三维导航定位误差（真值 ECEF/错误三维 ECEF/误差向量全字段；本配方姿态抽样为 0°，误差 0.0m）**
- 特殊事件监测与提示（探测/中断部分）：本场景 0 行——双星配方目标全程可探测、无生命周期中断事件；该指标由 `sbirs_wfov_nfov_handover` 专项场景覆盖（不在本包内）

## 审阅提示

- 日志行格式：`仿真时间=Xs 仿真周期=N [验收项：名称] 验收内容：…`；「无」= 该条件本周期不满足（如实标注），「暂无」= 库内无该实现（计时类，example 层兜底）。
- 干扰抑制比为负（−1.537dB）不是错误：单音多普勒落在 2 脉冲 MTI 滤波器响应大于 1 的频点，公式如实输出（该组行标注「未进判决」，不进主链）。
- rir_jammed_scan 的集群数量在干扰期间 2→3 抖动：干扰真实进入检测判决链（SINR 分母）的物理表现。
